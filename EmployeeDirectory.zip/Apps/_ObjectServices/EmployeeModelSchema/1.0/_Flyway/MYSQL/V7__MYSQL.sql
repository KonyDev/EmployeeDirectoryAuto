ALTER TABLE `Contact`
	ADD CONSTRAINT `3cb8525b9c12ca9ad69b7bc5b2a5d4` FOREIGN KEY(`Contact_type_id`) REFERENCES `Contact_type`(`Id`);
